package com.leyufore.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.leyufore.domain.User;
import com.leyufore.util.FactoryUtil;

import exception.BasicException;
import net.sf.json.JSONObject;

/**
 * 用户服务类
 * @author wenrule
 *
 */
public class UserService {
	
	/**
	 * 开户
	 * @param user	提交的用户信息
	 * @return	用户
	 * @throws BasicException 异常中包含提款失败的信息
	 */
	public User accountOpen(User user) throws BasicException{
		User account = FactoryUtil.getUserDao().findByIdentificationId(user.getIdentificationId());
		if(account != null){
			throw new BasicException("身份证号已经存在");
		}
		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
		user.setBankAccount(Long.parseLong(sf.format(new Date())));
		user.setCashBalance(10000);
		int id = FactoryUtil.getUserDao().insert(user);
		user.setId(id);
		return user;
	}
	
	/**
	 * 根据身份证信息查找用户
	 * @param identificationId	身份证信息
	 * @return	用户
	 */
	public User findUserByIdentificationId(long identificationId){
		User user = FactoryUtil.getUserDao().findByIdentificationId(identificationId);
		return user;
	}
	
	
	public static void main(String[] args){
		User user = new User();
		user.setIdentificationId(8);
		try {
			new UserService().accountOpen(user);
		} catch (BasicException e) {
			e.printStackTrace();
			System.out.println(e.getCustomMsg());
		}
	}
}
