package com.leyufore.service;

import java.util.ArrayList;
import java.util.List;

import org.bouncycastle.util.encoders.Base64;

import com.leyufore.dao.CoinDao;
import com.leyufore.dao.SpenderCoinDao;
import com.leyufore.dao.UserDao;
import com.leyufore.domain.Coin;
import com.leyufore.domain.ProtocolCoin;
import com.leyufore.domain.SpenderCoin;
import com.leyufore.domain.User;
import com.leyufore.util.FactoryUtil;
import com.leyufore.util.SignatureUtil;

import exception.BasicException;

/**
 * 电子现金服务类
 * @author wenrule
 *
 */
public class CoinService {
	/**
	 * 提款
	 * @param user_request	用户信息
	 * @param proCoinList	盲化的电子现金信息列表
	 * @return
	 * @throws BasicException	异常中包含提款失败的信息
	 */
	public List<ProtocolCoin> coinDraw(User user_request,List<ProtocolCoin> proCoinList) throws BasicException{
		if(proCoinList == null || proCoinList.size() == 0){
			throw new BasicException("提款金额不能为0");
		}
		if(user_request == null){
			throw new BasicException("没有提供用户user");
		}
		
		UserDao userDao = FactoryUtil.getUserDao();
		CoinDao coinDao = FactoryUtil.getCoinDao();
		User user = userDao.findByIdentificationId(user_request.getIdentificationId());
		//余额不足异常
		if(user.getCashBalance() < proCoinList.size()){
			throw new BasicException("账户余额不足");
		}
		//对盲化的电子现金信息列表逐一签名
		List<ProtocolCoin> signCoinList = new ArrayList<>();
		for(int i = 0 ;i < proCoinList.size(); i++){
			byte[] blindId = Base64.decode(proCoinList.get(i).getMsg());
			byte[] signId = SignatureUtil.sign(blindId);
			signCoinList.add(new ProtocolCoin(proCoinList.get(i).getId(), Base64.toBase64String(signId)));
		}
		//对签名的盲化的电子现金信息列表验证银行库中是否有重复
		for(int i = 0 ;i < signCoinList.size(); i++){
			Coin coin = coinDao.findBySignId(signCoinList.get(i).getMsg());
			if(coin != null){
				throw new BasicException("银行中有相同的电子现金,不能提款");
			}
		}
		//对对签名的盲化的电子现金信息录入银行数据库中
		for(int i = 0 ;i < signCoinList.size(); i++){
			Coin coin = new Coin();
			coin.setSignId(signCoinList.get(i).getMsg());
			coinDao.insert(coin);
		}
		//更新数据库中用户信息
		user.setCashBalance(user.getCashBalance() - signCoinList.size());
		userDao.update(user);
		
		return signCoinList;
	}
	
	/**
	 * 验证并存储现金
	 * @param depositUser	申请存款的用户
	 * @param spenderCoinList	电子现金列表
	 * @throws BasicException	异常中包含提款失败的信息
	 */
	public void coinDeposit(User depositUser,List<SpenderCoin> spenderCoinList) throws BasicException{
		if(spenderCoinList == null || spenderCoinList.size()==0){
			throw new BasicException("存款金额不能为0");
		}
		if(depositUser == null){
			throw new BasicException("没有提供用户user");
		}
		
		UserDao userDao = FactoryUtil.getUserDao();
		SpenderCoinDao spenderCoinDao = FactoryUtil.getSpenderCoinDao();
		
		//验证电子现金合法性（即验证电子现金确实由银行签发）
		for(int i = 0; i < spenderCoinList.size(); i++){
			System.out.println(SignatureUtil.verify(spenderCoinList.get(i)));
			if(!SignatureUtil.verify(spenderCoinList.get(i))){
				throw new BasicException("存款现金中含有非银行签名的现金");
			}
		}
		
		//验证电子现金重复花费
		for(int i = 0; i < spenderCoinList.size();i++){
			SpenderCoin spenderCoin = spenderCoinDao.findCoinByCoinId(spenderCoinList.get(i).getCoidId());
			if(spenderCoin != null){
				throw new BasicException("该现金已在银行消费，请勿重复花费");
			}
		}
		
		//银行数据库中存入电子现金
		for(int i=0; i < spenderCoinList.size(); i++){
			spenderCoinDao.insert(spenderCoinList.get(i));
		}
		
		//更新数据库中用户信息
		depositUser.setCashBalance(depositUser.getCashBalance()+spenderCoinList.size());
		userDao.update(depositUser);
		
	}
	
	
	
}
