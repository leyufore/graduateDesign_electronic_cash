package com.leyufore.util;

import com.leyufore.dao.CoinDao;
import com.leyufore.dao.SpenderCoinDao;
import com.leyufore.dao.UserDao;
import com.leyufore.service.CoinService;
import com.leyufore.service.UserService;

/**
 * 工厂类
 * 提供创建好的Dao层和Service层组件
 * @author wenrule
 *
 */
public class FactoryUtil {
	
	private static UserDao userDao = new UserDao();
	private static UserService userService = new UserService();
	private static CoinDao coinDao = new CoinDao();
	private static CoinService coinService = new CoinService();
	private static SpenderCoinDao spenderCoinDao = new SpenderCoinDao();
	
	public static UserDao getUserDao(){
		return userDao;
	}
	public static UserService getUserService(){
		return userService;
	}
	public static CoinDao getCoinDao(){
		return coinDao;
	}
	public static CoinService getCoinService(){
		return coinService;
	}
	public static SpenderCoinDao getSpenderCoinDao(){
		return spenderCoinDao;
	}
}
