package com.leyufore.util;

import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.engines.RSAEngine;
import org.bouncycastle.crypto.params.RSAKeyParameters;
import org.bouncycastle.crypto.signers.PSSSigner;
import org.bouncycastle.crypto.util.PrivateKeyFactory;
import org.bouncycastle.crypto.util.PublicKeyFactory;
import org.bouncycastle.util.encoders.Base64;

import com.leyufore.domain.SpenderCoin;
/**
 * 电子现金的签名与验证类
 * @author wenrule
 *
 */
public class SignatureUtil {
	/**
	 * 私钥
	 */
	private static RSAKeyParameters privateKey;
	/**
	 * 公钥
	 */
	private static RSAKeyParameters publicKey;
	
	/**
	 * 读取私钥，公钥
	 */
	static {
		try {
			privateKey = readPrivateKey();
			publicKey = readPublicKey();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 签名（加密）
	 * @param blindId	申请提款的盲化电子现金信息（字节数组）
	 * @return	签名的盲化电子现金信息（字节数组）
	 */
	public static byte[] sign(byte[] blindId) {
		// Sign the coin request using our private key.
		RSAEngine engine = new RSAEngine();
		engine.init(true, privateKey);
		return engine.processBlock(blindId, 0, blindId.length);
	}
	/**
	 * 验证签名（解密）（验证是否由银行签发)
	 * @param spenderCoin	电子现金
	 * @return	
	 */
	public static boolean verify(SpenderCoin spenderCoin) {
		// Verify that the coin has a valid signature using our public key.
		byte[] coinId = Base64.decode(spenderCoin.getCoidId());
		byte[] signature = Base64.decode(spenderCoin.getSignId());

		PSSSigner signer = new PSSSigner(new RSAEngine(), new SHA1Digest(), 20);
		signer.init(false, publicKey);

		signer.update(coinId, 0, coinId.length);

		return signer.verifySignature(signature);
	}
	
	/**
	 * 银行公钥，私钥一旦生成，就不再改变。请确保客户端与服务端私钥公钥文件相同。
	 * 读取银行公钥
	 * @return
	 * @throws Exception
	 */
	private static RSAKeyParameters readPublicKey() throws Exception {
		String filePath = "/Library/Apache-tomcat-8.0.30/wtpwebapps/EcashManagementSystem/Keypair/publicKey.pub";
		byte[] publicKeyByte = readKeyToByteArray(filePath);
		ASN1Primitive asn1Primitive = ASN1Primitive.fromByteArray(publicKeyByte);
		RSAKeyParameters pubKey = (RSAKeyParameters) PublicKeyFactory.createKey(SubjectPublicKeyInfo.getInstance(asn1Primitive));
        return pubKey;
	}
	/**
	 * 银行公钥，私钥一旦生成，就不再改变。请确保客户端与服务端私钥公钥文件相同。
	 * 读取银行私钥
	 * @return
	 * @throws Exception
	 */
	private static RSAKeyParameters readPrivateKey() throws Exception{
		String filePath = "/Library/Apache-tomcat-8.0.30/wtpwebapps/EcashManagementSystem/Keypair/privateKey.pri";
		byte[] privateKeyByte = readKeyToByteArray(filePath);
		RSAKeyParameters priKey = (RSAKeyParameters) PrivateKeyFactory.createKey(privateKeyByte);
        return priKey;	
	}
	/**
	 * 将文件读取进字节数组
	 * @param filename 文件路径
	 * @return	文件的字节数组内容
	 * @throws Exception
	 */
	private static byte[] readKeyToByteArray(String filename) throws Exception {
		File f = new File(filename);
		FileChannel channel = null;
		FileInputStream fs = null;
		fs = new FileInputStream(f);
		channel = fs.getChannel();
		ByteBuffer byteBuffer = ByteBuffer.allocate((int) channel.size());
		while ((channel.read(byteBuffer)) > 0) {
		}
		channel.close();
		fs.close();
		return byteBuffer.array();
	}
	
}
