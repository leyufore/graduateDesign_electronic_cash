package com.leyufore.domain;

/**
 * 申请提款的电子现金信息
 * @author wenrule
 */
public class Coin {
	/**
	 * 客户端生成的随机数
	 */
	int id;
	/**
	 * 银行对随机数签名后的信息串
	 */
	String signId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSignId() {
		return signId;
	}
	public void setSignId(String signId) {
		this.signId = signId;
	}
	
}
