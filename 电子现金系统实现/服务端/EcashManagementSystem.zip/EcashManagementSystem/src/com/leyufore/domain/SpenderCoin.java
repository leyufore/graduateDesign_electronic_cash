package com.leyufore.domain;

/**
 * 电子现金
 * Created by wenrule on 16/5/24.
 */
public class SpenderCoin {
	/**
	 * 主键
	 */
    private int id;
    /**
     * 客户端随机产生的随机数
     */
    private String coidId;
    /**
     * 随机数经过银行签名后的信息串
     */
    private String signId;

    public String getCoidId() {
        return coidId;
    }

    public void setCoidId(String coidId) {
        this.coidId = coidId;
    }

    public String getSignId() {
        return signId;
    }

    public void setSignId(String signId) {
        this.signId = signId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
