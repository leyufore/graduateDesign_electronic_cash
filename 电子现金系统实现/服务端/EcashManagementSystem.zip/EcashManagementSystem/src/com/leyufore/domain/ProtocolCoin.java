package com.leyufore.domain;

/**
 * 请求的信息数据
 * Created by wenrule on 16/5/24.
 */
public class ProtocolCoin {
    int id;
    String msg;
    
    public ProtocolCoin(){
    	
    }
    public ProtocolCoin(int id, String msg) {
        this.id = id;
        this.msg = msg;
    }
    
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


}
