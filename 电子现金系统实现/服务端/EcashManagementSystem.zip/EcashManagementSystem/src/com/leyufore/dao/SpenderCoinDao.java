package com.leyufore.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.leyufore.domain.Coin;
import com.leyufore.domain.SpenderCoin;

/**
 * 电子现金数据库操作类
 * @author wenrule
 *
 */
public class SpenderCoinDao {
	public Integer insert(SpenderCoin coin) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		Integer id = (Integer) session.save(coin);
		tx.commit();
		session.close();
		sf.close();
		return id;
	}

	public SpenderCoin findCoinByCoinId(String coinId) {
		SpenderCoin result = null;

		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		String sql = "SELECT * FROM ecash.spendcoin WHERE coin_id = '" + coinId + "'";
		List resultSet = session.createSQLQuery(sql).addEntity(SpenderCoin.class).list();
		Iterator iterator = resultSet.iterator();
		if (iterator.hasNext()) {
			result = (SpenderCoin) iterator.next();
		}
		tx.commit();
		session.close();
		sf.close();
		return result;
	}

	public static void main(String[] args) {
		/**
		 * String id =
		 * "PiWuF187ohKYN38Y9zeKu3RS6lHVvQEGzy/Td3tJp9q9RkD9vLt5WH1bG0Bksuxit8amIyTOtEjbzn16Q5ZSgOwvKej4nLZZStzcv1ddowsyyA9ts7ce/h5GzPVFTKGVuaUThQCNBJj/hlmBLBbqKYuLsmZ0ZpfsOI6Ks4KnnY/Pmi18Fz0Wf17hdM0gAYYmxkMy7y+bPrrsBEI3VHJ3cOUbhiS59ekNkyt27ct0iys3Pd2plLo55Vnlh1R4N8hASXhASUhBniUufth9QRjzVPf4fq/CEFtDYLMTEodJLwAOzkPEGUOUG1gw1vcLvGEV39vwPiz+Kn/cUYw5IoAS2A==";
		 * SpenderCoin spenderCoin = new SpenderCoin();
		 * spenderCoin.setCoidId(id); spenderCoin.setSignId(id); new
		 * SpenderCoinDao().insert(spenderCoin);
		 **/
		System.out.println(new SpenderCoinDao().findCoinByCoinId("1").getSignId());
	}
}
