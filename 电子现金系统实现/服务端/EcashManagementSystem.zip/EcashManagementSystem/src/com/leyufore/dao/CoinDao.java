package com.leyufore.dao;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.leyufore.domain.Coin;
import com.leyufore.domain.User;

/**
 * 申请提款的电子现金信息数据库操作类
 * @author wenrule
 *
 */
public class CoinDao {
	
	public Integer insert(Coin coin){
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		Integer id = (Integer) session.save(coin);
		tx.commit();
		session.close();
		sf.close();
		return id;
	}
	
	public Coin findBySignId(String signId){
		Coin result = null;

		Configuration conf = new Configuration().configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		String sql = "SELECT * FROM ecash.coin WHERE sign_id = '" + signId + "'";
		List resultSet = session.createSQLQuery(sql).addEntity(Coin.class).list();
		Iterator iterator = resultSet.iterator();
		if (iterator.hasNext()) {
			result = (Coin) iterator.next();
		}
		tx.commit();
		session.close();
		sf.close();
		return result;
	}

	public void delete(Coin coin){
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		session.delete(coin);
		tx.commit();
		session.close();
		sf.close();
		
	}
	
	public static void main(String[] args) {
		String signature = "PiWuF187ohKYN38Y9zeKu3RS6lHVvQEGzy/Td3tJp9q9RkD9vLt5WH1bG0Bksuxit8amIyTOtEjbzn16Q5ZSgOwvKej4nLZZStzcv1ddowsyyA9ts7ce/h5GzPVFTKGVuaUThQCNBJj/hlmBLBbqKYuLsmZ0ZpfsOI6Ks4KnnY/Pmi18Fz0Wf17hdM0gAYYmxkMy7y+bPrrsBEI3VHJ3cOUbhiS59ekNkyt27ct0iys3Pd2plLo55Vnlh1R4N8hASXhASUhBniUufth9QRjzVPf4fq/CEFtDYLMTEodJLwAOzkPEGUOUG1gw1vcLvGEV39vwPiz+Kn/cUYw5IoAS2A==";
		Coin coin = new Coin();
		coin.setSignId(signature);
		new CoinDao().insert(coin);
		/**
		String signature = "PiWuF187ohKYN38Y9zeKu3RS6lHVvQEGzy/Td3tJp9q9RkD9vLt5WH1bG0Bksuxit8amIyTOtEjbzn16Q5ZSgOwvKej4nLZZStzcv1ddowsyyA9ts7ce/h5GzPVFTKGVuaUThQCNBJj/hlmBLBbqKYuLsmZ0ZpfsOI6Ks4KnnY/Pmi18Fz0Wf17hdM0gAYYmxkMy7y+bPrrsBEI3VHJ3cOUbhiS59ekNkyt27ct0iys3Pd2plLo55Vnlh1R4N8hASXhASUhBniUufth9QRjzVPf4fq/CEFtDYLMTEodJLwAOzkPEGUOUG1gw1vcLvGEV39vwPiz+Kn/cUYw5IoAS2A==";
		Coin coin = new CoinDao().findBySignId(signature);
		System.out.println(coin.getId());
		**/
		/**
		String signature = "PiWuF187ohKYN38Y9zeKu3RS6lHVvQEGzy/Td3tJp9q9RkD9vLt5WH1bG0Bksuxit8amIyTOtEjbzn16Q5ZSgOwvKej4nLZZStzcv1ddowsyyA9ts7ce/h5GzPVFTKGVuaUThQCNBJj/hlmBLBbqKYuLsmZ0ZpfsOI6Ks4KnnY/Pmi18Fz0Wf17hdM0gAYYmxkMy7y+bPrrsBEI3VHJ3cOUbhiS59ekNkyt27ct0iys3Pd2plLo55Vnlh1R4N8hASXhASUhBniUufth9QRjzVPf4fq/CEFtDYLMTEodJLwAOzkPEGUOUG1gw1vcLvGEV39vwPiz+Kn/cUYw5IoAS2A==";
		Coin coin = new Coin();
		coin.setId(2);
		coin.setSignId(signature);
		new CoinDao().delete(coin);
		**/
		/**
		Coin coin = new CoinDao().findBySignId("123");
		if(coin == null){
			System.out.println("leyufore coin null");
		}
		**/
	}
}
