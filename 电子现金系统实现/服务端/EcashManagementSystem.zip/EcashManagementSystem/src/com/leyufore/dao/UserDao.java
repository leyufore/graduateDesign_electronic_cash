package com.leyufore.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.leyufore.domain.User;

/**
 * 用户数据库操作类
 * @author wenrule
 *
 */
public class UserDao extends HibernateDaoSupport {

	public Integer insert(User user) {
		Configuration conf = new Configuration().configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		Integer id = (Integer) session.save(user);
		tx.commit();
		session.close();
		sf.close();
		return id;
	}
	public void update(User user){
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		session.update(user);
		tx.commit();
		session.close();
		sf.close();
	}
	public User findByIdentificationId(long identificationId) {
		User result = null;

		Configuration conf = new Configuration().configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		String sql = "SELECT * FROM ecash.user WHERE identification_id = " + identificationId;
		List resultSet = session.createSQLQuery(sql).addEntity(User.class).list();
		Iterator iterator = resultSet.iterator();
		if (iterator.hasNext()) {
			result = (User) iterator.next();
		}
		tx.commit();
		session.close();
		sf.close();
		return result;
	}

	public User findByBancAccount(long bankAccount) {
		User result = null;

		Configuration conf = new Configuration().configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		String sql = "SELECT * FROM ecash.user WHERE bank_account = " + bankAccount;
		List resultSet = session.createSQLQuery(sql).addEntity(User.class).list();
		Iterator iterator = resultSet.iterator();
		if (iterator.hasNext()) {
			result = (User) iterator.next();
		}
		tx.commit();
		session.close();
		sf.close();
		return result;
	}

	public static void main(String[] args) {
		/**
		User user = new UserDao().findByIdentificationId(11);
		System.out.print(user);
		**/
		User user = new UserDao().findByIdentificationId(1);
		user.setCashBalance(200);
		new UserDao().update(user);
	}
}
