package com.leyufore.action;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.Out;
import org.apache.struts2.ServletActionContext;
import org.springframework.http.HttpRequest;

import com.leyufore.domain.Coin;
import com.leyufore.domain.ProtocolCoin;
import com.leyufore.domain.SpenderCoin;
import com.leyufore.domain.User;
import com.leyufore.util.FactoryUtil;
import com.leyufore.util.SignatureUtil;
import com.opensymphony.xwork2.ActionSupport;

import exception.BasicException;
import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 电子现金请求处理类
 * @author wenrule
 *
 */
public class CoinAction extends ActionSupport{
	/**
	 * 提款请求处理
	 */
	public void coinDraw() throws IOException{
		//获取请求中的数据
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setCharacterEncoding("utf-8");
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
		StringBuffer sb = new StringBuffer();
		String temp;
		while((temp = br.readLine()) != null){
			sb.append(temp);
		}
		JSONObject coinDrawJson = JSONObject.fromObject(sb.toString());
		System.out.println(coinDrawJson.toString());
		User user = (User) JSONObject.toBean(coinDrawJson.getJSONObject("user"),User.class);
		JSONArray jsonArray = coinDrawJson.getJSONArray("protocolCoinList");
		List<ProtocolCoin> protocolCoinsList = new ArrayList<>();
		for(int i = 0; i < jsonArray.size(); i++){
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			ProtocolCoin protocolCoin = (ProtocolCoin) JSONObject.toBean(jsonObject, ProtocolCoin.class);
			protocolCoinsList.add(protocolCoin);
		}
		System.out.println("user bankAccount" + user.getBankAccount());
		for(int i = 0; i < protocolCoinsList.size(); i++){
			System.out.println(protocolCoinsList.get(i).getMsg());
		}
		JSONObject resultJson = new JSONObject();
		try{
			List<ProtocolCoin> resultList = FactoryUtil.getCoinService().coinDraw(user, protocolCoinsList);
			User resultUser = FactoryUtil.getUserService().findUserByIdentificationId(user.getIdentificationId());
			resultJson.put("code", 200);
			resultJson.put("user", resultUser);
			resultJson.put("protocolCoinList", resultList);
		}catch(BasicException e){
			resultJson.put("code", 400);
			resultJson.put("msg", e.getCustomMsg());
		}
		System.out.println(resultJson);
		//封装从Service层返回的信息，发送给客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println(resultJson);
		out.flush();
		out.close();
	}
	
	/**
	 * 存款请求处理
	 * @throws IOException
	 */
	public void coinDeposit() throws IOException{
		//获取请求中的数据
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setCharacterEncoding("utf-8");
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
		StringBuffer sb = new StringBuffer();
		String temp;
		while((temp = br.readLine()) != null){
			sb.append(temp);
		}
		JSONObject coinDepositJson = JSONObject.fromObject(sb.toString());
		System.out.println(coinDepositJson.toString());
		User user = (User) JSONObject.toBean(coinDepositJson.getJSONObject("user"), User.class);
		JSONArray jsonArray = coinDepositJson.getJSONArray("depositCoinList");
		List<SpenderCoin> coinDepositList = new ArrayList<>();
		for(int i = 0 ; i < jsonArray.size(); i++){
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			SpenderCoin coin = new SpenderCoin();
			coin.setId(jsonObject.getInt("id"));
			coin.setCoidId(jsonObject.getString("coidId"));
			coin.setSignId(jsonObject.getString("signId"));
			coinDepositList.add(coin);
		}
		JSONObject resultJson = new JSONObject();
		try {
			FactoryUtil.getCoinService().coinDeposit(user, coinDepositList);
			User depositUser = FactoryUtil.getUserService().findUserByIdentificationId(user.getIdentificationId());
			resultJson.put("code", 200);
			resultJson.put("user", depositUser);
		} catch (BasicException e) {
			e.printStackTrace();
			resultJson.put("code", 400);
			resultJson.put("msg", e.getCustomMsg());
		}
		System.out.println(resultJson);
		//封装从Service层返回的信息，发送给客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println(resultJson);
		out.flush();
		out.close();
		
	}
}
