package com.leyufore.action;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.leyufore.domain.User;
import com.leyufore.util.FactoryUtil;
import com.opensymphony.xwork2.ActionSupport;

import exception.BasicException;
import net.sf.json.JSONObject;

/**
 * 用户请求处理类
 * @author wenrule
 *
 */
public class UserAction extends ActionSupport{
	
	public void jsonTest() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(),"utf-8"));
		StringBuffer sb = new StringBuffer();
		String temp;
		while((temp = br.readLine()) != null){
			sb.append(temp);
		}
		br.close();
		System.out.println(request.getContentType());
		System.out.println(sb);
		JSONObject idJsonOj = JSONObject.fromObject(sb.toString());
		System.out.println(idJsonOj.get("identificationId"));
		
		User user = new User();
		user.setIdentificationId(64444);
		user.setBankAccount(312313);
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("user", user);
		out.println(jsonObject);
		out.flush();
		out.close();
	}
	/**
	 * 开户请求处理
	 */
	public void accountOpen() throws IOException{
		//获取请求中的数据
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setCharacterEncoding("utf-8");
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream(), "utf-8"));
		StringBuffer sb = new StringBuffer();
		String temp;
		while((temp = br.readLine())!=null){
			sb.append(temp);
		}
		JSONObject userJson = JSONObject.fromObject(sb.toString());
		User receiveUser = (User) JSONObject.toBean(userJson, User.class);
		System.out.println(receiveUser.getIdentificationId());
		
		//封装从Service层返回的信息，发送给客户端
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		try {
			User resultUser = FactoryUtil.getUserService().accountOpen(receiveUser);
			JSONObject resultJson = new JSONObject();
			resultJson.put("code", 200);
			resultJson.put("user", resultUser);
			System.out.println(resultJson);
			out.println(resultJson);
		} catch (BasicException e) {
			JSONObject resultJson = new JSONObject();
			resultJson.put("code",400);
			resultJson.put("msg", e.getCustomMsg());
			System.out.println(resultJson);
			out.println(resultJson);
		}
		out.flush();
		out.close();
	}
	
	
}
