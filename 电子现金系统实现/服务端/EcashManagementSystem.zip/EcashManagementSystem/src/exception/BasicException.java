package exception;

/**
 * 异常类 -- 保存业务中失败的信息
 * @author wenrule
 */
public class BasicException extends Exception{
	
	private static final long serialVersionUID = 1L;
	/**
	 * 异常信息（存储业务中失败的原因）
	 */
	private String customMsg;
	
	public BasicException(String msg){
		this.customMsg = msg;
	}
	
	public String getCustomMsg() {
		return customMsg;
	}
}
