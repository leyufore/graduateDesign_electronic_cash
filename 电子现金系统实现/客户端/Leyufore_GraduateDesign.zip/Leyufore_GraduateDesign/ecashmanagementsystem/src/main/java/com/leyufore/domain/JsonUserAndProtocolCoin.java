package com.leyufore.domain;

import java.util.List;

/**
 * 请求的数据结构，用于包装发送json格式数据。
 * 该数据结构可以不用，没有必要使用
 * Created by wenrule on 16/5/24.
 */
public class JsonUserAndProtocolCoin {
    private User user;
    private List<ProtocolCoin> protocolCoinList;

    public JsonUserAndProtocolCoin(User user,List<ProtocolCoin> protocolCoinList) {
        this.protocolCoinList = protocolCoinList;
        this.user = user;
    }

    public List<ProtocolCoin> getProtocolCoinList() {
        return protocolCoinList;
    }

    public void setProtocolCoinList(List<ProtocolCoin> protocolCoinList) {
        this.protocolCoinList = protocolCoinList;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
