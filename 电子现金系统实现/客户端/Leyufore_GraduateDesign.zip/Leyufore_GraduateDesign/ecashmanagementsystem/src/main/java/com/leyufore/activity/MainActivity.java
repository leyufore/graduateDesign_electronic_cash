package com.leyufore.activity;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.leyufore.R;
import com.leyufore.domain.Coin;
import com.leyufore.domain.JsonUserAndProtocolCoin;
import com.leyufore.domain.ProtocolCoin;
import com.leyufore.domain.User;
import com.leyufore.util.BlindSignatureUtil;
import com.leyufore.util.CommonUtil;
import com.leyufore.util.LogUtil;

import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.util.Iterable;
import org.bouncycastle.util.encoders.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * 主界面
 * 使用流程：
 * 1.用户，商家开户
 * 2.用户，商家提款
 * 3.商家开启监听
 * 4.用户搜索设备，搜索到商家设备后进行连接
 * 5.用户支付给商家。（商家接收到电子现金后自动进行存款)
 */
public class MainActivity extends Activity {

    private final int ACCOUNT_OPEN_REQUEST = 0;
    private final int COIN_DRAW_REQUEST = 1;
    private final int COIN_SPEND_RESPONSE = 2;

    private TextView tv_bank_account;
    private TextView tv_coin_balance;
    private TextView tv_coin_eBalance;
    private Button btn_account_open;
    private Button btn_coin_draw;
    private Button btn_coin_spend;
    private Button btn_bt_listen;
    private Button btn_bt_search;
    private TextView tv_bt_deviceName;
    private Button btn_bt_connect_close;

    private RequestQueue mQueue;

    /**
     * 页面中的数据
     */
    private User user;
    private List<Coin> coinList;
    private List<ProtocolCoin> protocolCoinList;
    /**
     * 请求过程中保存随机产生的coinId
     */
    private List<Coin> coinRequestTempList;

    //蓝牙相关
    private BluetoothAdapter mBtAdapter;
    private BluetoothServerSocket mBtServerSocket;
    private BluetoothSocket mBtSocket;
    //传输数据类
    private BluetoothTransferUtil mBtTransferUtil;

    private int mBtListenState = BT_LISTEN_CLOSE;
    private static final int BT_LISTEN_OPEN = 0;
    private static final int BT_LISTEN_CLOSE = 1;

    //设备页面请求返回返回
    private final int REQUEST_ACTIVITY_DEVICE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mQueue = Volley.newRequestQueue(this);

        coinList = new ArrayList<>();
        protocolCoinList = new ArrayList<>();
        coinRequestTempList = new ArrayList<>();

        //初始化
        initView();
        //注册监听器
        addListener();

        BlindSignatureUtil.init(getResources().openRawResource(R.raw.publickey));

        LogUtil.error("系统默认编码 ： " + System.getProperty("file.encoding"));
        LogUtil.error("系统默认语言 ： " + System.getProperty("user.language"));
        LogUtil.error("系统默认字符编码 ： " + Charset.defaultCharset());

    }

    /**
     * 初始化View
     */
    public void initView() {
        tv_bank_account = (TextView) findViewById(R.id.bank_account);
        tv_coin_balance = (TextView) findViewById(R.id.coin_balance);
        tv_coin_eBalance = (TextView) findViewById(R.id.coin_Ebalance);
        btn_account_open = (Button) findViewById(R.id.account_open);
        btn_coin_draw = (Button) findViewById(R.id.coin_draw);
        btn_coin_spend = (Button) findViewById(R.id.coin_spend);
        btn_bt_listen = (Button) findViewById(R.id.bluetooth_listen);
        btn_bt_search = (Button) findViewById(R.id.bluetooth_device_search);
        tv_bt_deviceName = (TextView) findViewById(R.id.bluetooth_device_name);
        btn_bt_connect_close = (Button) findViewById(R.id.bluetooth_connect_close);

    }

    /**
     * 添加监听器
     */
    public void addListener() {
        btn_account_open.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final EditText editText_identification = new EditText(MainActivity.this);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("请输入身份证号")
                        .setView(editText_identification)
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                long identificationId = Long.parseLong(editText_identification.getText().toString().trim());
                                try {
                                    sendAccountOpenRequest(identificationId);
                                } catch (JSONException e) {
                                    Toast.makeText(MainActivity.this, "account open json解析报错", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });
        btn_coin_draw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText editText_identification = new EditText(MainActivity.this);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("请输入提款金额")
                        .setView(editText_identification)
                        .setNegativeButton("取消", null)
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                int drawCount = Integer.parseInt(editText_identification.getText().toString().trim());
                                sendCoinDrawRequest(drawCount);
                            }
                        })
                        .show();
            }
        });
        btn_bt_listen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBtListenState == BT_LISTEN_CLOSE) {  //处于非监听状态
                    if (openBluetooth()) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    mBtServerSocket = mBtAdapter.listenUsingRfcommWithServiceRecord(NAME_SECURE, MY_UUID_SECURE);
                                } catch (IOException e) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(MainActivity.this, "mBtAdapter listenUsing error", Toast.LENGTH_SHORT).show();

                                        }
                                    });
                                    e.printStackTrace();
                                    return;
                                }
                                if (mBtServerSocket != null) {
                                    try {
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                mBtListenState = BT_LISTEN_OPEN;
                                                btn_bt_listen.setText("关闭监听");
                                            }
                                        });
                                        mBtSocket = mBtServerSocket.accept();
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                btn_bt_connect_close.setVisibility(View.VISIBLE);
                                                tv_bt_deviceName.setText(mBtSocket.getRemoteDevice().getName());
                                            }
                                        });
                                        //新开一个线程监听数据输入
                                        mBtTransferUtil = new BluetoothTransferUtil(mBtSocket, handler);
                                        mBtTransferUtil.start();
                                    } catch (IOException e) {
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(MainActivity.this, "mBtServerSocket accept error", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                        e.printStackTrace();
                                        return;
                                    }
                                }
                            }
                        }).start();
                    }
                } else {  //处于监听状态
                    try {
                        mBtServerSocket.close();
                        mBtListenState = BT_LISTEN_CLOSE;
                        btn_bt_listen.setText("开启监听");
                    } catch (IOException e) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "mBtServerSocket close error", Toast.LENGTH_SHORT).show();
                            }
                        });
                        e.printStackTrace();
                    }
                }
            }
        });
        btn_bt_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (openBluetooth()) {
                    Intent deviceIntent = new Intent(MainActivity.this, DeviceActivity.class);
                    startActivityForResult(deviceIntent, REQUEST_ACTIVITY_DEVICE);
                }
            }
        });
        btn_bt_connect_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBtSocket != null) {
                    try {
                        mBtSocket.close();
                        tv_bt_deviceName.setText("");
                        btn_bt_connect_close.setVisibility(View.GONE);
                    } catch (IOException e) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "mBtSocket close error", Toast.LENGTH_SHORT).show();
                            }
                        });
                        e.printStackTrace();
                        return;
                    }
                }
            }
        });
        btn_coin_spend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBtTransferUtil != null) {
                    final EditText editText_identification = new EditText(MainActivity.this);
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("请输入支付金额")
                            .setView(editText_identification)
                            .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    int count = Integer.parseInt(editText_identification.getText().toString().trim());
                                    /**
                                     * test signature
                                     */
                                    LogUtil.error("test signature");
                                    for(int i = 0 ; i< coinList.size();i++){
                                        LogUtil.error(coinList.get(i).getCoidId()+"\n" + coinList.get(i).getSignId());
                                        LogUtil.error(BlindSignatureUtil.verify(coinList.get(i)) +"");
                                    }
                                    if (count <= coinList.size()) {
                                        mBtTransferUtil.transferCoinFromSpenderToMerchant(coinList.subList(0, count));
                                    }

                                }
                            })
                            .setNegativeButton("取消", null)
                            .show();
                } else {
                    Toast.makeText(MainActivity.this, "请先进行蓝牙连接", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    /**
     * 从蓝牙搜索Activity返回结果时的处理
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_ACTIVITY_DEVICE:
                if (resultCode == RESULT_OK) {
                    String address = data.getStringExtra("device_address");
                    final BluetoothDevice device = mBtAdapter.getRemoteDevice(address);
                    Toast.makeText(this, device.getName() + "\n" + device.getAddress(), Toast.LENGTH_SHORT).show();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                mBtSocket = device.createRfcommSocketToServiceRecord(MY_UUID_SECURE);
                            } catch (IOException e) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(MainActivity.this, "device.createInsecureRfcomm error", Toast.LENGTH_SHORT).show();
                                    }
                                });
                                e.printStackTrace();
                                return;
                            }
                            if (mBtSocket != null) {
                                try {
                                    mBtSocket.connect();
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            btn_bt_connect_close.setVisibility(View.VISIBLE);
                                            tv_bt_deviceName.setText(device.getName());
                                        }
                                    });
                                    //创建传输数据线程
                                    mBtTransferUtil = new BluetoothTransferUtil(mBtSocket, handler);
                                    mBtTransferUtil.start();
                                } catch (IOException e) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(MainActivity.this, "connect failed", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                    e.printStackTrace();
                                    return;
                                }
                            }
                        }
                    }).start();
                }
                break;
        }
    }

    /**
     * handler处理信息，改变主界面UI
     */
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            User msgUser;
            switch (msg.what) {
                case ACCOUNT_OPEN_REQUEST:
                    msgUser = (User) msg.obj;
                    user = msgUser;
                    tv_bank_account.setText(String.valueOf(user.getBankAccount()));
                    tv_coin_balance.setText(String.valueOf(user.getCashBalance()));
                    tv_coin_eBalance.setText(String.valueOf(coinList.size()));
                    return;
                case COIN_DRAW_REQUEST:
                    msgUser = (User) msg.obj;
                    user = msgUser;
                    tv_coin_balance.setText(String.valueOf(user.getCashBalance()));
                    tv_coin_eBalance.setText(String.valueOf(coinList.size()));
                    break;
                case COIN_SPEND_RESPONSE:
                    String response = (String) msg.obj;
                    Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();

            }

        }
    };

    /**
     * 发送开户请求
     * @param identificationId 身份证号
     */
    private void sendAccountOpenRequest(long identificationId) throws JSONException {
        User user = new User();
        user.setIdentificationId(identificationId);

        Gson gson = new Gson();
        String user_json = gson.toJson(user);
        LogUtil.error("user toString : \n" + user_json);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                "http://192.168.1.107:8080/EcashManagementSystem/userAction_accountOpen",
                user_json,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        LogUtil.error(response.toString());
                        try {
                            Integer code = response.getInt("code");
                            if (code == 200) {
                                Toast.makeText(MainActivity.this, "开户成功", Toast.LENGTH_SHORT).show();
                                User user = new Gson().fromJson(response.getString("user"), User.class);
                                Message message = handler.obtainMessage(ACCOUNT_OPEN_REQUEST, user);
                                handler.sendMessage(message);
                            } else {
                                String msg = response.getString("msg");
                                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "account open volley报错", Toast.LENGTH_SHORT).show();
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }

    /**
     * 发送提款请求
     * @param drawCount 提款金额
     */
    private void sendCoinDrawRequest(int drawCount) {
        /**
         * 发之前先清空
         */
        coinRequestTempList.clear();
        protocolCoinList.clear();

        //申请提款前先进行盲因子参数重设
        BlindSignatureUtil.resetBlindParams();
        for (int i = 0; i < drawCount; i++) {
            byte[] coinId = CommonUtil.getRandomBytes(16);
            String signId;
            try {
                signId = BlindSignatureUtil.coinBlind(Base64.toBase64String(coinId));
            } catch (CryptoException e) {
                e.printStackTrace();
                LogUtil.error("盲化现金出错");
                Toast.makeText(this, "盲化现金出错", Toast.LENGTH_SHORT);
                return;
            }
            ProtocolCoin protocolCoin = new ProtocolCoin(i, signId);
            Coin coin = new Coin();
            coin.setId(i);
            coin.setCoidId(Base64.toBase64String(coinId));
            coinRequestTempList.add(coin);
            protocolCoinList.add(protocolCoin);
        }
        JsonUserAndProtocolCoin jsonUserAndProtocolCoin = new JsonUserAndProtocolCoin(user, protocolCoinList);
        Gson gson = new Gson();
        final String json_coinDrawRequest = gson.toJson(jsonUserAndProtocolCoin);
        LogUtil.error(json_coinDrawRequest);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                "http://192.168.1.107:8080/EcashManagementSystem/coinAction_coinDraw",
                json_coinDrawRequest,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        LogUtil.error(response.toString());
                        try {
                            Integer code = response.getInt("code");
                            if (code == 200) {
                                Toast.makeText(MainActivity.this, "提款成功", Toast.LENGTH_SHORT).show();
                                User user = new Gson().fromJson(response.getString("user"), User.class);
                                JSONArray jsonArray = response.getJSONArray("protocolCoinList");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    String blindSignMsg = jsonArray.getJSONObject(i).getString("msg");
                                    int id = jsonArray.getJSONObject(i).getInt("id");
                                    LogUtil.error("blindMsg :" + blindSignMsg);
                                    LogUtil.error("id :" + id);

                                    String signId = BlindSignatureUtil.coinUnblind(blindSignMsg);
                                    Coin coin = coinRequestTempList.get(id);
                                    coin.setSignId(signId);
                                    //校验银行签名
                                    LogUtil.error("coin draw request verify");
                                    if(BlindSignatureUtil.verify(coin)){
                                        LogUtil.error("coinId : "+coin.getCoidId());
                                        LogUtil.error("signId : "+coin.getSignId());
                                        LogUtil.error("true");
                                    }else {
                                        LogUtil.error("false");
                                    }
                                    coinList.add(coin);
                                }


                                Message message = handler.obtainMessage(COIN_DRAW_REQUEST, user);
                                handler.sendMessage(message);
                            } else {
                                String msg = response.getString("msg");
                                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            LogUtil.error("coinDrawRequest Json exception");
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "coin draw volley报错", Toast.LENGTH_SHORT).show();
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }

    // Name for the SDP record when creating server socket
    private static final String NAME_SECURE = "BluetoothChatSecure";
    private static final String NAME_INSECURE = "BluetoothChatInsecure";

    // Unique UUID for this application
    private static final UUID MY_UUID_SECURE =
            UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
    private static final UUID MY_UUID_INSECURE =
            UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");

    /**
     * 开启蓝牙
     *
     * @return
     */
    private boolean openBluetooth() {
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBtAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!mBtAdapter.isEnabled()) {
            mBtAdapter.enable();
        }
        return true;
    }

    /**
     * 蓝牙数据传输整体模块
     * 技术关键点；
     * 问题现象：蓝牙读取缓冲区的不确定性。当客户端A连续写两次信息时，客户端B不能确保读取2次。由于读写有缓冲区，
     * 客户端B有可能一次读取了所有的数据。
     * 这种特性造成了在支付过程中，不能准确地交互。
     * 解决方案：蓝牙传输过程，本质就是用户，商家客户端中的读写线程的交互。
     * （从多线程的思想中可更好的理解）
     * */
    private class BluetoothTransferUtil {

        private InputStream mInputStream;
        private OutputStream mOutputStrenm;
        private Handler mHandler;
        private int mTransferState;
        private static final int TRANSFER_STATE_SEND = 0;
        private static final int TRANSFER_STATE_RECEIVE = 1;

        public BluetoothTransferUtil(BluetoothSocket socket, Handler handler) {
            try {
                mInputStream = socket.getInputStream();
                mOutputStrenm = socket.getOutputStream();
            } catch (IOException e) {
                Toast.makeText(MainActivity.this, "BluetoothTransferUtil construtor failed", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
                return;
            }
            mHandler = handler;
            mTransferState = TRANSFER_STATE_RECEIVE;

        }

        //启动读线程
        public void start() {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        try {
                            String readStr = readString(mInputStream);
                            if (readStr.equals("支付请求")) {  //商家读线程
                                mOutputStrenm.write(getOk());
                                int count = Integer.parseInt(readString(mInputStream));
                                mOutputStrenm.write(getOk());
                                List<Coin> depositCoinList = new ArrayList<Coin>();
                                for (int i = 0; i < count; i++) {
                                    Coin coin = new Coin();
                                    coin.setId(Integer.parseInt(readString(mInputStream)));
                                    mOutputStrenm.write(getOk());
                                    coin.setCoidId(readCoinIdAndSignId(mInputStream));
                                    mOutputStrenm.write(getOk());
                                    coin.setSignId(readCoinIdAndSignId(mInputStream));
                                    mOutputStrenm.write(getOk());
                                    depositCoinList.add(coin);
                                }
                                if (readString(mInputStream).equals(("发送完成"))) {
                                    //网络发送银行存款
                                    LogUtil.error("开始网络发送存款电子现金");
                                    Map<String,Object> resultMap = new HashMap<String, Object>();
                                    resultMap.put("user",user);
                                    resultMap.put("depositCoinList",depositCoinList);
                                    Gson gson = new Gson();
                                    final String json_coinDepositRequest = gson.toJson(resultMap);
                                    LogUtil.error("json_coinDepositRequest :\n" +json_coinDepositRequest);
                                    JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                                            "http://192.168.1.107:8080/EcashManagementSystem/coinAction_coinDeposit",
                                            json_coinDepositRequest,
                                            new Response.Listener<JSONObject>() {
                                                @Override
                                                public void onResponse(JSONObject response) {
                                                    try {
                                                        Integer code = response.getInt("code");
                                                        if(code == 200){
                                                            Toast.makeText(MainActivity.this, "存款成功", Toast.LENGTH_SHORT).show();
                                                            mOutputStrenm.write(new String("支付响应支付成功").getBytes());
                                                        }else{
                                                            String msg = response.getString("msg");
                                                            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                                                            mOutputStrenm.write(new String("支付响应"+msg).getBytes());
                                                        }
                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                        LogUtil.error("coinDepositRequest Json exception");
                                                    } catch (IOException e) {
                                                        e.printStackTrace();
                                                        LogUtil.error("mOutputStrenm write 支付响应 exception");
                                                    }
                                                }
                                            }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Toast.makeText(MainActivity.this, "coin deposit volley报错", Toast.LENGTH_SHORT).show();
                                            error.printStackTrace();
                                            try {
                                                mOutputStrenm.write(new String("支付响应商家volley error").getBytes());
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                    mQueue.add(request);
                                }
                            } else {  //支付者读线程
                                if (readStr.equals("OK")) {
                                    mTransferState = TRANSFER_STATE_SEND;
                                } else if (readStr.contains("支付响应")) {
                                    Message msg = mHandler.obtainMessage(COIN_SPEND_RESPONSE, readStr.substring(4));
                                    mHandler.sendMessage(msg);
                                    mTransferState = TRANSFER_STATE_RECEIVE;
                                }

                            }
                        } catch (IOException e) {
                            LogUtil.error("BluetoothTransferUtil-start-mInputStream- read error");
                            e.printStackTrace();
                            break;
                        }
                    }
                }
            }).start();
        }

        //从支付者向商家传输电子现金
        public void transferCoinFromSpenderToMerchant(final List<Coin> spendCoinList) {
            mTransferState = TRANSFER_STATE_SEND;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        mOutputStrenm.write(new String("支付请求").getBytes());
                        mTransferState = TRANSFER_STATE_RECEIVE;
                        while (mTransferState != TRANSFER_STATE_SEND) {
                        }
                        String count = String.valueOf(spendCoinList.size());
                        mOutputStrenm.write(count.getBytes());
                        mTransferState = TRANSFER_STATE_RECEIVE;
                        while (mTransferState != TRANSFER_STATE_SEND) {
                        }
                        for (int i = 0; i < spendCoinList.size(); i++) {
                            Coin transferCoin = spendCoinList.get(i);
                            mOutputStrenm.write(String.valueOf(transferCoin.getId()).getBytes());
                            mTransferState = TRANSFER_STATE_RECEIVE;
                            while (mTransferState != TRANSFER_STATE_SEND) {
                            }
                            mOutputStrenm.write(Base64.decode(transferCoin.getCoidId()));
                            mTransferState = TRANSFER_STATE_RECEIVE;
                            while (mTransferState != TRANSFER_STATE_SEND) {
                            }
                            mOutputStrenm.write(Base64.decode(transferCoin.getSignId()));
                            mTransferState = TRANSFER_STATE_RECEIVE;
                            while (mTransferState != TRANSFER_STATE_SEND) {
                            }
                        }
                        mOutputStrenm.write(new String("发送完成").getBytes());
                        mTransferState = TRANSFER_STATE_RECEIVE;
                    } catch (IOException e) {
                        LogUtil.error("BluetoothTransferUtil-transferCoinFromSpenderToMerchant- error");
                        e.printStackTrace();
                        return;
                    }
                }
            }).start();
        }

        private String readString(InputStream mInputStream) throws IOException {
            String result;
            byte[] buffer = new byte[1024];
            int length;
            length = mInputStream.read(buffer);
            String validStr = new String(buffer, 0, length);
            LogUtil.error("readString validLength :" + length);
            LogUtil.error("readString valid Str :" + validStr);
            result = validStr;
            return result;
        }

        private String readCoinIdAndSignId(InputStream mInputStream) throws IOException {
            String result;
            byte[] buffer = new byte[1024];
            int length;
            length = mInputStream.read(buffer);
            String validStr = Base64.toBase64String(buffer,0,length);
            LogUtil.error("readString validLength :" + length);
            LogUtil.error("readString valid Str :" + validStr);
            result = validStr;
            return result;
        }

        private byte[] getOk() {
            return new String("OK").getBytes();
        }
    }
}
