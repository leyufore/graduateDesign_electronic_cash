package com.leyufore.activity;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.leyufore.R;

import java.util.Set;

/**
 * 蓝牙搜索设备Activity
 */
public class DeviceActivity extends Activity {

    private BluetoothAdapter mBtAdapter;
    /**
     * 已配对设备列表
     */
    private ListView pairedDeviceListView;
    /**
     * 新设备列表
     */
    private ListView newDeviceListView;
    private ArrayAdapter<String> mNewDevicesArrayAdapter;

    private Button btn_scan_device;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.activity_device);

        setResult(Activity.RESULT_CANCELED);

        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        initView();
        addListener();

        ArrayAdapter<String> pairedDevicesArrayAdapter = new ArrayAdapter<String>(this,R.layout.device_name);
        mNewDevicesArrayAdapter = new ArrayAdapter<String>(this,R.layout.device_name);

        pairedDeviceListView.setAdapter(pairedDevicesArrayAdapter);
        pairedDeviceListView.setOnItemClickListener(mDeviceClickListener);
        newDeviceListView.setAdapter(mNewDevicesArrayAdapter);
        newDeviceListView.setOnItemClickListener(mDeviceClickListener);

        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(mReceiver,filter);
        filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(mReceiver,filter);


        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
        if(pairedDevices.size() > 0){
            for(BluetoothDevice device : pairedDevices){
                pairedDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
            }
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mBtAdapter != null){
            mBtAdapter.cancelDiscovery();
        }
        unregisterReceiver(mReceiver);
    }

    public void initView(){
        pairedDeviceListView = (ListView) findViewById(R.id.paired_devices);
        newDeviceListView = (ListView) findViewById(R.id.new_devices);
        btn_scan_device = (Button) findViewById(R.id.button_scan);
    }

    /**
     * 添加监听器
     */
    public void addListener(){
        btn_scan_device.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                setProgressBarIndeterminateVisibility(true);
                setTitle("select a device to connect");
                if(mBtAdapter.isDiscovering()){
                    mBtAdapter.cancelDiscovery();
                }
                mBtAdapter.startDiscovery();
                Log.e("btn_scn_device","perform click");
            }
        });
    }

    /**
     * itemClick监听器
     */
    private AdapterView.OnItemClickListener mDeviceClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if(mBtAdapter.isDiscovering()) {
                mBtAdapter.cancelDiscovery();
            }
            String info = ((TextView)view).getText().toString();
            String address = info.substring(info.length() - 17);

            Intent intent = new Intent();
            intent.putExtra("device_address",address);
            setResult(Activity.RESULT_OK,intent);
            finish();
        }
    };

    /**
     * 广播接收器
     */
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if(BluetoothDevice.ACTION_FOUND.equals(action)){
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(device.getBondState() != BluetoothDevice.BOND_BONDED){
                    mNewDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                }
            }else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                setProgressBarIndeterminateVisibility(false);
                setTitle("discovery over");
            }
        }
    };


}
