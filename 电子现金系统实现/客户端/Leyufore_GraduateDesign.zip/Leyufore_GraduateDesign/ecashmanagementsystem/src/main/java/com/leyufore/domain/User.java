package com.leyufore.domain;

import com.google.gson.Gson;

import java.io.Serializable;

/**
 * 用户
 * Created by wenrule on 16/5/22.
 */
public class User implements Serializable{
    /**
     * 主键
     */
    private int id;
    /**
     * 身份证号码
     */
    private long identificationId;
    /**
     * 银行账号
     */
    private long bankAccount;
    /**
     * 银行余额
     */
    private int cashBalance;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getIdentificationId() {
        return identificationId;
    }

    public void setIdentificationId(long identificationId) {
        this.identificationId = identificationId;
    }

    public long getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(long bankAccount) {
        this.bankAccount = bankAccount;
    }

    public int getCashBalance() {
        return cashBalance;
    }

    public void setCashBalance(int cashBalance) {
        this.cashBalance = cashBalance;
    }

}
