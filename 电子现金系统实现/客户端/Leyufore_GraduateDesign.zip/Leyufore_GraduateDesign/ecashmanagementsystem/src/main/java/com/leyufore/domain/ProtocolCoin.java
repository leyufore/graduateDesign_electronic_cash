package com.leyufore.domain;

/**
 * 申请提款时的数据
 * Created by wenrule on 16/5/24.
 */
public class ProtocolCoin {
    int id;
    String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ProtocolCoin(int id, String msg) {
        this.id = id;
        this.msg = msg;
    }
}
