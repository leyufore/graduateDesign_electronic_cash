package com.leyufore.util;

import android.util.Log;

/**
 * Created by wenrule on 16/5/22.
 */
public class LogUtil {
    public static String TAG = "leyufore";

    public static void error(String value) {
        Log.e(TAG, value);
    }
}
