package com.leyufore.util;

import com.leyufore.domain.Coin;

import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.engines.RSABlindingEngine;
import org.bouncycastle.crypto.engines.RSAEngine;
import org.bouncycastle.crypto.generators.RSABlindingFactorGenerator;
import org.bouncycastle.crypto.params.RSABlindingParameters;
import org.bouncycastle.crypto.params.RSAKeyParameters;
import org.bouncycastle.crypto.signers.PSSSigner;
import org.bouncycastle.crypto.util.PublicKeyFactory;
import org.bouncycastle.util.encoders.Base64;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigInteger;


/**
 * 盲签名工具类
 */
public class BlindSignatureUtil {
    /**
     * 公钥
     */
    private static RSAKeyParameters publicKey;
    /**
     * 盲因子参数
     */
    private static RSABlindingParameters blindingParams;

    /**
     * 初始化BlindSignatureUtil，提供公钥文件读取流
     *
     * @param pubKeyInputStream 公钥文件读取流
     */
    public static void init(InputStream pubKeyInputStream) {
        try {
            publicKey = readPublicKey(pubKeyInputStream);

        } catch (Exception e) {
            /**
             * 在Android中出现异常，程序依然会继续往下运行
             * leyufore
             */
            e.printStackTrace();
        }
    }

    /**
     * 重置盲因子参数
     */
    public static void resetBlindParams() {
        // Generate a blinding factor using the bank's public key.
        RSABlindingFactorGenerator blindingFactorGenerator = new RSABlindingFactorGenerator();
        blindingFactorGenerator.init(publicKey);

        BigInteger blindingFactor = blindingFactorGenerator.generateBlindingFactor();

        blindingParams = new RSABlindingParameters(publicKey, blindingFactor);
    }

    /**
     * 盲化coinId
     * @param coinId    用户产生的随机数m
     * @return  盲化后的数 b(m)
     * @throws CryptoException
     */
    public static String coinBlind(String coinId) throws CryptoException {
        byte[] byteCoinId = Base64.decode(coinId);
        // "Blind" the coin and generate a coin request to be signed by the
        // bank.
        PSSSigner signer = new PSSSigner(new RSABlindingEngine(),
                new SHA1Digest(), 20);
        signer.init(true, blindingParams);

        signer.update(byteCoinId, 0, byteCoinId.length);

        byte[] sig = signer.generateSignature();

        return Base64.toBase64String(sig);
    }

    /**
     * 解盲signId
     * @param signId    盲化后的数b(m)经过银行签名而得到的s(b(m)）
     * @return  去盲后的带有银行签名的coin s(m) = b'(s(b(m))
     */
    public static String coinUnblind(String signId){
        byte[] byteSignId = Base64.decode(signId);
        // "Unblind" the bank's signature (so to speak) and create a new coin
        // using the ID and the unblinded signature.
        RSABlindingEngine blindingEngine = new RSABlindingEngine();
        blindingEngine.init(false, blindingParams);

        byte[] s = blindingEngine.processBlock(byteSignId, 0, byteSignId.length);

        return Base64.toBase64String(s);
    }

    /**
     * 验证Coin是由银行签名
     * @param coin
     * @return
     */
    public static boolean verify(Coin coin) {
        // Verify that the coin has a valid signature using our public key.
        byte[] coinId = Base64.decode(coin.getCoidId());
        byte[] signature = Base64.decode(coin.getSignId());

        PSSSigner signer = new PSSSigner(new RSAEngine(), new SHA1Digest(), 20);
        signer.init(false, publicKey);

        signer.update(coinId, 0, coinId.length);

        return signer.verifySignature(signature);
    }

    /**
     * 从公钥文件输入流中读取文件到字节数组中
     * @param pubKeyInputStream
     * @return
     * @throws Exception
     */
    private static byte[] readInputStream(InputStream pubKeyInputStream) throws Exception {
        byte[] buffer = new byte[1024];
        int len = -1;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        while ((len = pubKeyInputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, len);
        }
        outputStream.close();
        pubKeyInputStream.close();
        return outputStream.toByteArray();
    }

    /**
     * 读取公钥
     * @param pubKeyInputStream 公钥文件输入流
     * @return
     * @throws Exception
     */
    private static RSAKeyParameters readPublicKey(InputStream pubKeyInputStream) throws Exception {
        byte[] publicKeyByte = readInputStream(pubKeyInputStream);
        ASN1Primitive asn1Primitive = ASN1Primitive.fromByteArray(publicKeyByte);
        RSAKeyParameters pubKey = (RSAKeyParameters) PublicKeyFactory.createKey(SubjectPublicKeyInfo.getInstance(asn1Primitive));
        return pubKey;
    }
}
